To use this project bundle, simply copy the contents of this zip file to your CIRCUITPY drive. Contents include:
* the code.py file
* the lib/ folder and all of its contents (including subfolders and .mpy files)
* any assets (such as images, sounds, etc.)

NOTE: This will replace the current code.py, and the lib folder and its contents. Back up any desired code before copying these files!

This zip was downloaded from https://learn.adafruit.com/pyportal-bitcoin-value-display/bitcoin-value-display on April 16, 2021.
